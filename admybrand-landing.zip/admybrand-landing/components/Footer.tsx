export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-6 text-center">
      © 2025 ADmyBRAND. All rights reserved.
    </footer>
  );
}
