export default function Testimonials() {
  return (
    <section className="bg-gray-100 p-10 text-center">
      <h2 className="text-3xl font-semibold mb-6">What Our Users Say</h2>
      <div className="italic text-gray-600 max-w-2xl mx-auto">
        "ADmyBRAND has transformed our marketing workflow. It's truly AI-powered magic!"
      </div>
    </section>
  );
}
