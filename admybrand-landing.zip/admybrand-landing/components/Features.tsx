export default function Features() {
  const features = [
    "AI Ad Creation", "Smart Budgeting", "Real-time Insights",
    "Audience Targeting", "Omni-channel", "Automation Suite"
  ];
  return (
    <section className="p-10 bg-gray-50">
      <h2 className="text-3xl font-semibold text-center mb-6">Features</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {features.map((feature, idx) => (
          <div key={idx} className="p-4 border rounded-xl shadow text-center">
            {feature}
          </div>
        ))}
      </div>
    </section>
  );
}
