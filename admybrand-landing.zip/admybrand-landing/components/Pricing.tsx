export default function Pricing() {
  const plans = [
    { name: "Starter", price: "$29/mo", features: ["Basic Analytics", "1 User"] },
    { name: "Pro", price: "$99/mo", features: ["All Starter Features", "5 Users", "AI Campaigns"] },
    { name: "Enterprise", price: "Custom", features: ["All Pro Features", "Unlimited Users", "Dedicated Support"] }
  ];
  return (
    <section className="p-10 bg-white">
      <h2 className="text-3xl font-semibold text-center mb-6">Pricing</h2>
      <div className="flex flex-col md:flex-row justify-center gap-6">
        {plans.map((plan, idx) => (
          <div key={idx} className="border rounded-xl p-6 shadow w-72">
            <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
            <p className="text-2xl font-semibold mb-4">{plan.price}</p>
            <ul className="space-y-2">
              {plan.features.map((f, i) => <li key={i}>✅ {f}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
