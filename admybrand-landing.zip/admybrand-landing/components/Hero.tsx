export default function Hero() {
  return (
    <section className="text-center py-20 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
      <h1 className="text-5xl font-bold mb-4">Welcome to ADmyBRAND AI Suite</h1>
      <p className="text-xl">AI-powered marketing redefined.</p>
    </section>
  );
}
